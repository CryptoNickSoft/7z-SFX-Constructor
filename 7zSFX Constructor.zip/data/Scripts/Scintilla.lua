ScriptEditor = {};
ScriptEditor.ObjectName = "ScriptEditor";
ScriptEditor.ObjectWnd = 0;
ScriptEditor.Syntax = {};
--
local string = string;
local tostring = tostring;
local String = String;
local math = math;
local tonumber = tonumber;
local Math = Math;
--
ScriptEditor.LoadSysntaxList = function()
	local tList = File.Find(sScriptsFolder, "*.ini", true, false, nil, nil);
	ScriptEditor.Syntax = {};
	--
	if tList ~= nil then
		for x, sFullPath in ipairs(tList) do
			local tPath = String.SplitPath(sFullPath);
			ScriptEditor.Syntax[tPath.Filename] = sFullPath;
			Settings.SetConfigPath(sFullPath, tPath.Filename);
		end
	end
end

ScriptEditor.GetSysntaxList = function()
	return ScriptEditor.Syntax;
end;
--
ScriptEditor.Create = function(hWnd)
	local WinAPI = {};
	WinAPI.CreateWindowEx = function(iExStyle, sClassName, sWindowName, iStyle, iX, iY, iWidth, iHeight, hWndParent, hMenu, hInstance, lParam)
		if hWnd ~= 0 then
			local hUser32 = Library.Load("user32.dll");
			local nRet = hUser32.CreateWindowExA(iExStyle, sClassName, sWindowName, iStyle, iX, iY, iWidth, iHeight, hWndParent, hMenu, hInstance, lParam);
			hUser32:Close_();
			--
			return nRet;
		else
			return 0;
		end
	end
	-- hWnd: HWND ���� ���������. ���� �� ������� ����� �������������� HWND �������� �������.
	local tData = Input.GetProperties(ScriptEditor.ObjectName);
	if tData ~= nil then
		local hWnd = tData.WindowHandle;
		-- local hWnd = hWnd or DialogEx.GetWndHandle();
		--
		-- local tSize = Window.GetSize(hWnd);
		local tSize = Input.GetSize(ScriptEditor.ObjectName);
		DLL.CallFunction("kernel32.dll", "LoadLibraryA", "\""..SCIdll.."\"", DLL_RETURN_TYPE_INTEGER, DLL_CALL_STDCALL);
		--
		ScriptEditor.ObjectWnd = WinAPI.CreateWindowEx(0, "Scintilla", "SciLexer", WS_VISIBLE+WS_CHILD+WS_CLIPCHILDREN+WS_TABSTOP+WS_BORDER, 0, 0, tSize.Width, tSize.Height, hWnd, 0, 0, 0);
		ScriptEditor.OnSize();
		local tSize = Window.GetSize(hWnd);
		if tSize ~= nul then
		Window.SetSize(hWnd, tSize.Width+1, tSize.Height+1);
		Window.SetSize(hWnd, tSize.Width, tSize.Height);
		end
		--
		if Subclass.HasSubclass(ScriptEditor.ObjectWnd) == true then
			Subclass.Remove(ScriptEditor.ObjectWnd);
		end
		ScriptEditor.Subclass = function(hWnd, uMsg, wParam, lParam)
			if uMsg == WM_KEYDOWN then
				if wParam == 0x9 then
					-- Tab
					ScriptEditor.SendMessage(SCI_GRABFOCUS);
				elseif wParam == 0x70 then
					-- F1
					HelpMe();
					return 0;
				elseif wParam == 0x71 then
					-- F2
					HelpProg();
					return 0;
				elseif wParam == 0x72 then
					-- F3
					HelpVariables();
					return 0;
				elseif wParam == 0x74 then
					-- F5
					Paragraph.SetText("InfoStatus", "");
					SfxBuilder();
					GluingFiles();
					return 0;					
				elseif wParam == 0x77 then
					-- F8
					Paragraph.SetText("InfoStatus", "");
					ReBuild();
					return 0;
				elseif wParam == 0x78 then
					-- F9
					File.ExploreFolder(sSource.."\\", SW_SHOWNORMAL);
					return 0;
				end
			elseif uMsg == WM_CLOSE then
				if Subclass.HasSubclass(ScriptEditor.ObjectWnd) == true then
					Subclass.Remove(ScriptEditor.ObjectWnd);
				end
			end
			--
			return Subclass.OldWinProc(hWnd, uMsg, wParam, lParam);
		end
		Subclass.Create(ScriptEditor.ObjectWnd, ScriptEditor.Subclass);
		--
		return true;
	else
		return false;
	end
end
ScriptEditor.OnSize = function(sPageName)
	local sObjectName = ScriptEditor.ObjectName;
	local hWnd = ScriptEditor.ObjectWnd;
	local tSize = Input.GetSize(sObjectName);
	local tPos = Input.GetPos(sObjectName);
	--
	Window.SetSize(hWnd, tSize.Width, tSize.Height);
	Window.SetPos(hWnd, 0, 0);
end
-- �������������� ��������� ��������� 
-- ������ �������� ��������� ���� �,
-- ���� ������� ������������ �� ����� ������, �� ������� ����������� ����
ScriptEditor.Init = function()
	local hWnd = ScriptEditor.ObjectWnd;
	--
	ScriptEditor.SendMessage(SCI_SETTABWIDTH, 4);
	ScriptEditor.SendMessage(SCI_SETINDENTATIONGUIDES, 4, 1);
	ScriptEditor.SendMessage(SCI_SETMARGINTYPEN, MARGIN_SCRIPT_NUMBER, SC_MARGIN_NUMBER);
	ScriptEditor.SendMessage(SCI_SETMARGINWIDTHN, MARGIN_SCRIPT_NUMBER, tonumber(ScriptEditor.SendMessage(SCI_TEXTWIDTH, STYLE_LINENUMBER, "_999")));
	ScriptEditor.SendMessage(SCI_SETMARGINWIDTHN, MARGIN_SCRIPT_ICON, 16);
	ScriptEditor.SendMessage(SCI_AUTOCSETSEPARATOR, String.Asc("\r\n"), 0);
	ScriptEditor.SendMessage(SCI_AUTOCSETIGNORECASE, 1);
	--
	ScriptEditor.SendMessage(SCI_SETINDENTATIONGUIDES, SC_IV_LOOKBOTH);
	--
	local tOSVersion = System.GetOSVersionInfo();
	if tOSVersion ~= nil and (tonumber(tOSVersion.MajorVersion) or 0) > 6 then
		-- On Windows Vista and newer
		ScriptEditor.SendMessage(SC_TECHNOLOGY_DIRECTWRITE);
	else
		ScriptEditor.SendMessage(SC_TECHNOLOGY_DEFAULT);
	end
end
--
ScriptEditor.GetText = function()
	local hWnd = ScriptEditor.ObjectWnd;
	--
	local nRet = "";
	local nLen = ScriptEditor.SendMessage(SCI_GETTEXT, 0, 0);
	local hBuf = MemoryEx.Allocate(nLen+1);
	--
	ScriptEditor.SendMessage(SCI_GETTEXT, nLen+1, hBuf); 
	nRet = MemoryEx.String(hBuf, -1, MEMEX_ASCII);
	MemoryEx.Free(hBuf);
	--
	return nRet;
end
ScriptEditor.GetLine = function(nLine)
	local hWnd = ScriptEditor.ObjectWnd;
	--
	local nRet = "";
	local nLen = ScriptEditor.SendMessage(SCI_GETLINE, nLine, 0);
	local hBuf = MemoryEx.Allocate(nLen+1);
	--
	ScriptEditor.SendMessage(SCI_GETLINE, nLine, hBuf);
	nRet = MemoryEx.String(hBuf, -1, MEMEX_ASCII);
	MemoryEx.Free(hBuf);
	--
	return nRet;
end

ScriptEditor.SetMarginWidth = function(nType, nWidth)
    ScriptEditor.SendMessage(SCI_SETMARGINWIDTHN, nType, nWidth);
end

ScriptEditor.GetCurrentLine = function()
	local hWnd = ScriptEditor.ObjectWnd;
	--
	local nRet = "";
	local nLen = ScriptEditor.SendMessage(SCI_GETCURLINE, 0, 0);
	local hBuf = MemoryEx.Allocate(nLen+1);
	--
	ScriptEditor.SendMessage(SCI_GETCURLINE, nLen+1, hBuf);
	nRet = MemoryEx.String(hBuf, -1, MEMEX_ASCII);
	MemoryEx.Free(hBuf);
	--
	return nRet;
end

ScriptEditor.ClearText = function()
	ScriptEditor.SendMessage(SCI_CLEARALL, 0, 0);
end

ScriptEditor.AddText = function(sText)
	local hBuf = MemoryEx.Allocate(#sText+1);
	local nRet = MemoryEx.String(hBuf, #sText+1, MEMEX_ASCII, sText);
	ScriptEditor.SendMessage(SCI_ADDTEXT, #sText+1, hBuf);
	MemoryEx.Free(hBuf);
end

ScriptEditor.SetText = function(sText, bForgetHistiry)
	local hBuf = MemoryEx.Allocate(#sText+1);
	local nRet = MemoryEx.String(hBuf, #sText+1, MEMEX_ASCII, sText);
	ScriptEditor.SendMessage(SCI_SETTEXT, 0, hBuf);
	MemoryEx.Free(hBuf);
	--
	if bForgetHistiry == nil or bForgetHistiry == true then
		ScriptEditor.SendMessage(SCI_EMPTYUNDOBUFFER);
	end
end

ScriptEditor.InsertText = function(sText, nPos)
	local hBuf = MemoryEx.Allocate(#sText+1);
	local nRet = MemoryEx.String(hBuf, #sText+1, MEMEX_ASCII, sText);
	ScriptEditor.SendMessage(SCI_INSERTTEXT, nPos or -1, hBuf);
	MemoryEx.Free(hBuf);
end

ScriptEditor.GetCursorPos = function()
	return ScriptEditor.SendMessage(SCI_GETCURRENTPOS, 0, 0); 
end;

-- Document
ScriptEditor.IsModified = function()
	return ScriptEditor.ToBool(ScriptEditor.SendMessage(SCI_GETMODIFY));
end;

ScriptEditor.GetWrapMode = function()
	return ScriptEditor.SendMessage(SCI_GETWRAPMODE);
end;

ScriptEditor.SetWrapMode = function(nMode)
	ScriptEditor.SendMessage(SCI_SETWRAPMODE, nMode);
end;

-- Undo/Redo
ScriptEditor.ResetUndo = function()
	ScriptEditor.SendMessage(SCI_EMPTYUNDOBUFFER);
end;

ScriptEditor.CanUndo = function()
	return ScriptEditor.ToBool(ScriptEditor.SendMessage(SCI_CANUNDO));
end;

ScriptEditor.Undo = function()
	ScriptEditor.SendMessage(SCI_UNDO);
end;

ScriptEditor.CanRedo = function()
	return ScriptEditor.ToBool(ScriptEditor.SendMessage(SCI_CANREDO));
end;

ScriptEditor.Redo = function()
	ScriptEditor.SendMessage(SCI_REDO);
end;

-- Selection
ScriptEditor.GetSelectionStart = function()
	return ScriptEditor.SendMessage(SCI_GETSELECTIONSTART);
end;

ScriptEditor.GetSelectionEnd = function()
	return ScriptEditor.SendMessage(SCI_GETSELECTIONEND);
end;

ScriptEditor.SetSelectionStart = function(nPos)
	ScriptEditor.SendMessage(SCI_SETSELECTIONSTART, nPos);
end;

ScriptEditor.SetSelectionEnd = function(nPos)
	ScriptEditor.SendMessage(SCI_SETSELECTIONEND, nPos);
end;

ScriptEditor.RemoveSelection = function(nPos)
	ScriptEditor.SendMessage(SCI_SETEMPTYSELECTION, nPos);
end;

ScriptEditor.SelectAll = function()
	ScriptEditor.SendMessage(SCI_SELECTALL, nPos);
end;

ScriptEditor.SetSelection = function(nStart, nEnd)
	ScriptEditor.SendMessage(SCI_SETSEL, nStart, nEnd);
end;

-- Jump
ScriptEditor.GoToLine = function(nLineNumber)
	ScriptEditor.SendMessage(SCI_GOTOLINE, nLineNumber);
end;

ScriptEditor.GoToChar = function(nCharPos)
	ScriptEditor.SendMessage(SCI_GOTOPOS, nCharPos);
end;

-- Cut/Copy/Paste/Delete
ScriptEditor.CanPaste = function()
	return ScriptEditor.ToBool(ScriptEditor.SendMessage(SCI_CANPASTE));
end;

ScriptEditor.CanCopy = function()
	return ScriptEditor.ToBool(ScriptEditor.SendMessage(SCI_GETSELECTIONEMPTY));
end;

ScriptEditor.CanCut = function()
	return ScriptEditor.ToBool(ScriptEditor.SendMessage(SCI_GETSELECTIONEMPTY));
end;

ScriptEditor.Paste = function()
	ScriptEditor.SendMessage(SCI_PASTE);
end;

ScriptEditor.Copy = function()
	ScriptEditor.SendMessage(SCI_COPY);
end;

ScriptEditor.Cut = function()
	ScriptEditor.SendMessage(SCI_CUT);
end;

ScriptEditor.Delete = function()
	ScriptEditor.SendMessage(SCI_CLEAR);
end;

ScriptEditor.DeleteRange = function(nStart, nEnd)
	local nStart = nStart or ScriptEditor.GetSelectionStart();
	local nEnd = nEnd or ScriptEditor.GetSelectionEnd();
	--
	local sText = ScriptEditor.GetText();
	local sNewText = string.format("%s%s", string.sub(sText, 0, nStart), string.sub(sText, nEnd+1, -1));
	ScriptEditor.SetText(sNewText, false);
end;
--
ScriptEditor.StyleResetDafault = function()
	return ScriptEditor.SendMessage(SCI_STYLERESETDEFAULT, 0, 0); 
end;

-- �������� ���������
-- hWnd: ���������� Sci
-- Msg: ���������
-- wParam, lParam: ���������
ScriptEditor.SendMessage = function(Msg, wParam, lParam)
	local hWnd = ScriptEditor.ObjectWnd;
	assert(Msg);
	--
	local wParam = wParam or 0;
	local lParam = lParam or 0;
	--
	if type(lParam) == "string" then
		lParam = "\""..lParam.."\"";
	end
	--
	if type(wParam) == "string" then
		wParam = "\""..wParam.."\"";
	end
	--
	return DLL.CallFunction("user32.dll", "SendMessageA", hWnd..","..Msg..","..wParam..","..lParam, DLL_RETURN_TYPE_LONG, DLL_CALL_STDCALL);
end
-- ��������� �����
-- hWnd: ���������� Sci
-- nStyle: ����� �����
-- nForeColor: ���� ������
-- nBackColor: ���� ����
-- nSize: ������ ������
-- strFont: ��� ����������
-- bBold, bItalic, bUnderline: ����� ���������� (������, ������, ������������)
ScriptEditor.SetStyle = function(nStyle, nForeColor, nBackColor, nSize, strFont, bBold, bItalic, bUnderline)
	local hWnd = ScriptEditor.ObjectWnd;
	--
	local nSize = nSize or 0;
	local strFont = strFont or "";
	local bBold = bBold or false;
	local bItalic = bItalic or false;
	local bUnderine = bUnderline or false;
	--
	if bBold == true then bBold = 1; else bBold = 0; end
	if bItalic == true then bItalic = 1; else bItalic = 0; end
	if bUnderline == true then bUnderline = 1; else bUnderline = 0; end
	
	ScriptEditor.SendMessage(SCI_STYLESETFORE, nStyle, nForeColor);
	ScriptEditor.SendMessage(SCI_STYLESETBACK, nStyle, nBackColor);
	if nSize >= 1 then
		ScriptEditor.SendMessage(SCI_STYLESETSIZE, nStyle, nSize);
	end
	if strFont ~= "" then
		ScriptEditor.SendMessage(SCI_STYLESETFONT, nStyle, strFont, "str");
	end
	ScriptEditor.SendMessage(SCI_STYLESETBOLD, nStyle, bBold);
	ScriptEditor.SendMessage(SCI_STYLESETBOLD, nStyle, bItalic);
	ScriptEditor.SendMessage(SCI_STYLESETBOLD, nStyle, bUnderline);
end
ScriptEditor.SetAStyle = function(nStyle, nForeColor, nBackColor, nSize, strFont, bBold, bItalic, bUnderline)
	ScriptEditor.SendMessage(SCI_STYLESETFORE, nStyle, nForeColor);
	ScriptEditor.SendMessage(SCI_STYLESETBACK, nStyle, nBackColor);
	if nSize >= 1 then
		ScriptEditor.SendMessage(SCI_STYLESETSIZE, nStyle, nSize);
	end
	if strFont ~= "" then
		ScriptEditor.SendMessage(SCI_STYLESETFONT, nStyle, strFont);
	end
end
-- ��������� ��������
-- hWnd: ���������� Sci
-- vProperty: ��������
-- vValue: ��������
ScriptEditor.SetProperty = function(vProperty, vValue)
	local hWnd = ScriptEditor.ObjectWnd;
	--
	return ScriptEditor.SendMessage(SCI_SETPROPERTY, vProperty, vValue);
end
-- ����� ���������� ���������� ����������
ScriptEditor.SetLexer = function(sSyntaxStyle)
	local hWnd = ScriptEditor.ObjectWnd;
	--
	String.Or = function(a, b)
		if a == "" and b ~= "" then
			return b;
		elseif a ~= "" and b == "" then
			return a;
		elseif a ~= "" and b ~= "" then
			return a;
		end
	end

	ScriptEditor.StyleResetDafault()
	local nLexer = tonumber(Settings.GetValueData(sSyntaxStyle, "Config", "Lexer")) or SCLEX_NULL;
	ScriptEditor.SendMessage(SCI_SETLEXER, nLexer);
	-- ������� ���������
	local sGeneralTextColor = Settings.GetValueData(sSyntaxStyle, "General", "TextColor");
	local sGeneralBackColor = Settings.GetValueData(sSyntaxStyle, "General", "BackColor");
	local nGeneralFontSize = Settings.GetValueData(sSyntaxStyle, "General", "FontSize");
	local sGeneralFontName = Settings.GetValueData(sSyntaxStyle, "General", "FontName");
	local nGeneralStyle = _G[Settings.GetValueData(sSyntaxStyle, "General", "Style")] or 0;
	--
	ScriptEditor.SetStyle(STYLE_DEFAULT, Math.HexColorToNumber(sGeneralTextColor), Math.HexColorToNumber(sGeneralBackColor), tonumber(nGeneralFontSize), sGeneralFontName);
	ScriptEditor.SendMessage(SCI_STYLECLEARALL, 0, 0);
	ScriptEditor.SetStyle(nGeneralStyle, Math.HexColorToNumber(sGeneralTextColor), Math.HexColorToNumber(sGeneralBackColor), tonumber(nGeneralFontSize), sGeneralFontName);
	-- Indent Guide
	ScriptEditor.SetStyle(STYLE_INDENTGUIDE, Math.HexColorToNumber("777777"), Math.HexColorToNumber(sGeneralBackColor));
	-- ʊ������� �����
	local tValues = Settings.GetValueNames(sSyntaxStyle, "Keywords");
	if tValues ~= nil then
		for i = 0, KEYWORDSET_MAX do
			local sSet = string.format("KeywordSet%d", i+1);
			--
			local sKeywords = Settings.GetValueData(sSyntaxStyle, "Keywords", sSet);
			if sKeywords ~= "" then				
				local nStyle = _G[Settings.GetValueData(sSyntaxStyle, sSet, "Style")] or 0;
				if nStyle ~= 0 then
					ScriptEditor.SendMessage(SCI_SETKEYWORDS, i, sKeywords);
					--
					local sTextColor = String.Or(Settings.GetValueData(sSyntaxStyle, sSet, "TextColor"), sGeneralTextColor);
					local sBackColor = String.Or(Settings.GetValueData(sSyntaxStyle, sSet, "BackColor"), sGeneralBackColor);
					ScriptEditor.SetStyle(nStyle, Math.HexColorToNumber(sTextColor), Math.HexColorToNumber(sBackColor));
				end
			end
		end
	end
	--
	local tSections = Settings.GetSectionNames(sSyntaxStyle);
	if tSections ~= nil then
		for x, y in ipairs(tSections) do
			if String.Lower(String.Left(y, 6)) == String.Lower("Style.") then
				local nStyle = _G[Settings.GetValueData(sSyntaxStyle, y, "Style")] or 0;
				if nStyle ~= 0 then
					local sTextColor = Settings.GetValueData(sSyntaxStyle, y, "TextColor");
					local sBackColor = Settings.GetValueData(sSyntaxStyle, y, "BackColor");
					--
					ScriptEditor.SetStyle(nStyle, Math.HexColorToNumber(sTextColor), Math.HexColorToNumber(sBackColor), nil, nil, false, true);
				end
			end
		end
	end
end

--
ScriptEditor.ToBool = function(x, bExistanse)
	local x = x or nil;
	if type(x) == "string" then
		if bExistanse == true then
			if x ~= nil then
				return true;
			else
				return false;
			end
		else
			if String.Lower(x) == "true" or x == "1" then
				return true;
			else
				return false;
			end
		end
	elseif type(x) == "boolean" then
		return x;
	elseif type(x) == "number" then
		if x == 1 then
			return true;
		else
			return false;
		end
	else
		return false;
	end
end;

ScriptEditor.ToNumber = function(x)
	if type(x) == "boolean" then
		if x == true then
			return 1;
		else
			return 0;
		end
	elseif type(x) == "string" then
		local sLower = string.lower(x);
		if sLower == "true" then
			return 1;
		elseif sLower == "false" then
			return 0;
		else
			return tonumber(x);
		end
	else
		return tonumber(x);
	end
end;

ScriptEditor.ToTable = function(x)
	if type(x) == "table" then
		return x;
	else
		return nil;
	end
end;




